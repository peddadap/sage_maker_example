# scripts/text_module.py
LARGE_TEXT = """
This is an example of a large text string stored in a subdirectory called 'data'.
It can contain any large document, paragraph, or text needed for processing.
"""
